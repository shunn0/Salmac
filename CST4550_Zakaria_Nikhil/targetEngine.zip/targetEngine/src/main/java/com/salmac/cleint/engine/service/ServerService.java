package com.salmac.cleint.engine.service;

import org.springframework.stereotype.Service;

@Service
public class ServerService {

}
