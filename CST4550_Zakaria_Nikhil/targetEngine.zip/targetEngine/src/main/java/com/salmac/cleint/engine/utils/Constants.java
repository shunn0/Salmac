package com.salmac.cleint.engine.utils;

public class Constants {
    public static final int SERVER_STATUS_CHECK_INTERVAL = 12000;//One min
}
